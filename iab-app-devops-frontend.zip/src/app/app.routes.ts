import { Routes } from '@angular/router';
import { WorkspaceComponent } from './presentation/workspace/workspace.component';

export const routes: Routes = [
  {
    path: '',
    component: WorkspaceComponent
  }
];
