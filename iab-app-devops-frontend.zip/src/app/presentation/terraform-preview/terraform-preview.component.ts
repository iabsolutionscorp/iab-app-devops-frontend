import { Component } from '@angular/core';

@Component({
  selector: 'app-terraform-preview',
  imports: [],
  templateUrl: './terraform-preview.component.html',
  styleUrl: './terraform-preview.component.css'
})
export class TerraformPreviewComponent {

}
