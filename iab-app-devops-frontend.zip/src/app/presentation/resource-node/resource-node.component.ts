import { Component } from '@angular/core';

@Component({
  selector: 'app-resource-node',
  imports: [],
  templateUrl: './resource-node.component.html',
  styleUrl: './resource-node.component.css'
})
export class ResourceNodeComponent {

}
